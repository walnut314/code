package main
import format "fmt"

func main() {
	format.Printf("Hello World!\n")
}
