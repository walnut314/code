package main

func main() {
	var a1 [100]int
	var matrix [4][4]float64
	a2 := [...]int{1, 1, 2, 3, 5}
}
