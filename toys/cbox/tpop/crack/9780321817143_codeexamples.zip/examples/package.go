package example

type Public interface {}
